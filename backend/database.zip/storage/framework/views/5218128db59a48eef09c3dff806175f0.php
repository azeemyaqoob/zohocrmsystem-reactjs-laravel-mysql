<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>New Submission on 247CashOffer.com</title>
</head>
<body>
    <p>Hi Ron,</p>
    <p>There's a new submission on 247CashOffer</p>

    <ul>

        <li><strong>First Name:</strong> <?php echo e($freeOffer->first_name); ?></li>
        <li><strong>Last Name:</strong> <?php echo e($freeOffer->last_name); ?></li>
        <li><strong>Email:</strong> <?php echo e($freeOffer->email); ?></li>
        <li><strong>Phone:</strong> <?php echo e($freeOffer->phone); ?></li>
        <li><strong>Property Address:</strong> <?php echo e($freeOffer->full_address); ?></li>
        <li><strong>Contact Time:</strong> <?php echo e($freeOffer->best_time_to_contact ?? 'N/A'); ?></li>
        <li><strong>Reference:</strong> <?php echo e($freeOffer->hear_about_us ?? 'N/A'); ?></li>
    </ul>

    <p>Thank you!</p>
</body>
</html>
<?php /**PATH C:\247cashoffer_backend\cashoffer247_backend\resources\views/emails/freeOfferCreated.blade.php ENDPATH**/ ?>